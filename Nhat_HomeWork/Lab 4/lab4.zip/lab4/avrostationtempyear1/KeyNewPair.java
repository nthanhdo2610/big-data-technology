package avrostationtempyear1;

import java.util.Objects;



//public class KeyNew extends ComparableComparator implements Writable, Comparable<KeyNew>{
public class KeyNewPair {
	
	int year =0;
	
	String stationID = "";
	
	KeyNewPair() {
		
	}
	
	KeyNewPair(String stationID, int year) {
		
		this.year = year;
		this.stationID = stationID	;	
	}
	
	
	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		this.year = year;
	}




	public String getStationID() {
		return stationID;
	}

	public void setStationID(String stationID) {
		this.stationID = stationID;
	}

	
	@Override
	public boolean equals(Object obj) {
		
		if (obj == null) return false;
		if (obj.getClass().equals("KeyNew"))
			return true;
		KeyNewPair k = (KeyNewPair) obj;
		if (k.getStationID().toString().equals(this.getStationID().toString()) && k.getYear() == this.getYear()) {
			return true;
			
		}
		return false;
	}
	
	@Override
		public int hashCode() {
			// TODO Auto-generated method stub
			return Objects.hashCode(this.getStationID() + "" + this.getYear());
		}


}
