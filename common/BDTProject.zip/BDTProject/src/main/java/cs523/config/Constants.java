package cs523.config;

public class Constants {
    public static String KAFKA_BROKERS = "localhost:9092";
    public static String TOPIC ="BTD_FinalProject";
    public static Integer MESSAGE_SIZE=100000000;
    public static String APP_NAME = "FinalProject";
    public static String MASTER = "local[*]";
}
