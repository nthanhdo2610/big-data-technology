package miu.edu.bdt.producer;

import org.junit.jupiter.api.Test;

//import com.google.gson.Gson;

class ProducerServiceTest {

//    private static final Gson gson = new Gson();

    @Test
    void getWeatherData() {

    }
}